"use client"

import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { 
  Calendar, 
  Users, 
  BarChart3, 
  ArrowRight, 
  CheckCircle2, 
  Zap, 
  Shield, 
  Clock
} from "lucide-react"

export default function HomePage() {
  return (
    &lt;div className="min-h-screen bg-background"&gt;
      {/* Header */}
      &lt;header className="border-b border-border/40 backdrop-blur-sm fixed top-0 left-0 right-0 z-50 bg-background/80"&gt;
        &lt;div className="container mx-auto px-4 h-16 flex items-center justify-between"&gt;
          &lt;Link href="/" className="flex items-center gap-3"&gt;
            &lt;Image 
              src="/logo.png" 
              alt="MK Barber" 
              width={40} 
              height={40}
              className="rounded-lg"
            /&gt;
            &lt;span className="font-semibold text-lg"&gt;MK Barber&lt;/span&gt;
          &lt;/Link&gt;
          &lt;nav className="hidden md:flex items-center gap-8"&gt;
            &lt;Link href="#funcionalidades" className="text-sm text-muted-foreground hover:text-foreground transition-colors"&gt;
              Funcionalidades
            &lt;/Link&gt;
            &lt;Link href="#beneficios" className="text-sm text-muted-foreground hover:text-foreground transition-colors"&gt;
              Benefícios
            &lt;/Link&gt;
            &lt;Link href="#preco" className="text-sm text-muted-foreground hover:text-foreground transition-colors"&gt;
              Preço
            &lt;/Link&gt;
          &lt;/nav&gt;
          &lt;div className="flex items-center gap-3"&gt;
            &lt;Link href="/login"&gt;
              &lt;Button variant="ghost" size="sm"&gt;Já sou assinante&lt;/Button&gt;
            &lt;/Link&gt;
            &lt;Link href="/assinar"&gt;
              &lt;Button size="sm" className="gap-2"&gt;
                Comece Agora
                &lt;ArrowRight className="size-3" /&gt;
              &lt;/Button&gt;
            &lt;/Link&gt;
          &lt;/div&gt;
        &lt;/div&gt;
      &lt;/header&gt;

      {/* Hero */}
      &lt;main className="pt-32 pb-20"&gt;
        &lt;div className="container mx-auto px-4"&gt;
          &lt;div className="max-w-3xl mx-auto text-center"&gt;
            &lt;div className="flex justify-center mb-8"&gt;
              &lt;Image 
                src="/logo.png" 
                alt="MK Barber" 
                width={120} 
                height={120}
                className="rounded-2xl"
              /&gt;
            &lt;/div&gt;
            &lt;div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm mb-6"&gt;
              &lt;span className="size-1.5 rounded-full bg-primary animate-pulse" /&gt;
              Sistema de Gestão para Barbearias
            &lt;/div&gt;
            &lt;h1 className="text-4xl md:text-6xl font-bold tracking-tight text-balance mb-6"&gt;
              Transforme sua barbearia em um{" "}
              &lt;span className="text-primary"&gt;negócio organizado&lt;/span&gt;
            &lt;/h1&gt;
            &lt;p className="text-lg text-muted-foreground mb-8 text-pretty max-w-2xl mx-auto"&gt;
              Tenha controle total da sua agenda, clientes e desempenho. 
              Simplifique seu dia a dia e foque no que você faz de melhor: cortar cabelo.
            &lt;/p&gt;
            
            {/* CTA Principal */}
            &lt;div className="flex flex-col sm:flex-row gap-4 justify-center mb-6"&gt;
              &lt;Link href="/assinar"&gt;
                &lt;Button size="lg" className="gap-2 w-full sm:w-auto text-base px-8 py-6"&gt;
                  Comece Agora
                  &lt;ArrowRight className="size-4" /&gt;
                &lt;/Button&gt;
              &lt;/Link&gt;
            &lt;/div&gt;
            &lt;p className="text-sm text-muted-foreground"&gt;
              Assine e tenha acesso completo ao sistema
            &lt;/p&gt;
          &lt;/div&gt;

          {/* Features Grid */}
          &lt;div className="grid md:grid-cols-3 gap-6 mt-24" id="funcionalidades"&gt;
            &lt;FeatureCard 
              icon={Calendar}
              title="Agendamento Online"
              description="Seus clientes agendam 24/7. Você gerencia tudo em tempo real."
            /&gt;
            &lt;FeatureCard 
              icon={Users}
              title="Gestão de Clientes"
              description="Histórico completo, preferências e fidelização automática."
            /&gt;
            &lt;FeatureCard 
              icon={BarChart3}
              title="Relatórios Inteligentes"
              description="Métricas de desempenho e insights para crescer seu negócio."
            /&gt;
          &lt;/div&gt;

          {/* Benefits */}
          &lt;div className="mt-24" id="beneficios"&gt;
            &lt;h2 className="text-2xl md:text-3xl font-bold text-center mb-4"&gt;
              Por que escolher o MK Barber?
            &lt;/h2&gt;
            &lt;p className="text-muted-foreground text-center mb-12 max-w-xl mx-auto"&gt;
              Tudo que você precisa para gerenciar sua barbearia em um único lugar
            &lt;/p&gt;
            
            &lt;div className="grid md:grid-cols-2 gap-4 max-w-3xl mx-auto"&gt;
              &lt;BenefitItem 
                icon={Clock}
                text="Reduza faltas com lembretes automáticos"
              /&gt;
              &lt;BenefitItem 
                icon={Users}
                text="Múltiplos barbeiros em uma só conta"
              /&gt;
              &lt;BenefitItem 
                icon={Zap}
                text="Interface rápida e fácil de usar"
              /&gt;
              &lt;BenefitItem 
                icon={Shield}
                text="Seus dados sempre seguros"
              /&gt;
            &lt;/div&gt;
          &lt;/div&gt;

          {/* Pricing */}
          &lt;div className="mt-24" id="preco"&gt;
            &lt;h2 className="text-2xl md:text-3xl font-bold text-center mb-4"&gt;
              Plano simples e acessível
            &lt;/h2&gt;
            &lt;p className="text-muted-foreground text-center mb-12 max-w-xl mx-auto"&gt;
              Sem surpresas. Um único plano com todas as funcionalidades.
            &lt;/p&gt;
            
            &lt;div className="max-w-md mx-auto"&gt;
              &lt;div className="p-8 rounded-2xl bg-card border border-border relative overflow-hidden"&gt;
                &lt;div className="absolute top-0 right-0 px-3 py-1 bg-primary text-primary-foreground text-xs font-medium rounded-bl-lg"&gt;
                  Mensal
                &lt;/div&gt;
                
                &lt;div className="text-center mb-6"&gt;
                  &lt;h3 className="text-xl font-semibold mb-2"&gt;MK Barber Completo&lt;/h3&gt;
                  &lt;div className="flex items-baseline justify-center gap-1"&gt;
                    &lt;span className="text-4xl font-bold"&gt;R$ 49&lt;/span&gt;
                    &lt;span className="text-muted-foreground"&gt;/mês&lt;/span&gt;
                  &lt;/div&gt;
                &lt;/div&gt;

                &lt;div className="space-y-3 mb-8"&gt;
                  &lt;PricingFeature text="Agendamentos ilimitados" /&gt;
                  &lt;PricingFeature text="Gestão de clientes" /&gt;
                  &lt;PricingFeature text="Calendário inteligente" /&gt;
                  &lt;PricingFeature text="Relatórios completos" /&gt;
                  &lt;PricingFeature text="Suporte prioritário" /&gt;
                  &lt;PricingFeature text="Página de agendamento personalizada" /&gt;
                &lt;/div&gt;

                &lt;Link href="/assinar" className="block"&gt;
                  &lt;Button size="lg" className="w-full gap-2"&gt;
                    Comece Agora
                    &lt;ArrowRight className="size-4" /&gt;
                  &lt;/Button&gt;
                &lt;/Link&gt;
              &lt;/div&gt;
            &lt;/div&gt;
          &lt;/div&gt;

          {/* CTA Section */}
          &lt;div className="mt-24 p-8 md:p-12 rounded-2xl bg-card border border-border text-center"&gt;
            &lt;h2 className="text-2xl md:text-3xl font-bold mb-4"&gt;
              Pronto para organizar sua barbearia?
            &lt;/h2&gt;
            &lt;p className="text-muted-foreground mb-8 max-w-lg mx-auto"&gt;
              Assine agora e comece a usar o MK Barber em minutos. 
              Configure sua conta e receba agendamentos ainda hoje.
            &lt;/p&gt;
            &lt;Link href="/assinar"&gt;
              &lt;Button size="lg" className="gap-2 text-base px-8 py-6"&gt;
                Comece Agora
                &lt;ArrowRight className="size-4" /&gt;
              &lt;/Button&gt;
            &lt;/Link&gt;
          &lt;/div&gt;
        &lt;/div&gt;
      &lt;/main&gt;

      {/* Footer */}
      &lt;footer className="border-t border-border py-8"&gt;
        &lt;div className="container mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4"&gt;
          &lt;Link href="/" className="flex items-center gap-2"&gt;
            &lt;Image 
              src="/logo.png" 
              alt="MK Barber" 
              width={24} 
              height={24}
              className="rounded-md"
            /&gt;
            &lt;span className="text-sm text-muted-foreground"&gt;MK Barber&lt;/span&gt;
          &lt;/Link&gt;
          &lt;div className="flex items-center gap-6 text-sm text-muted-foreground"&gt;
            &lt;Link href="#" className="hover:text-foreground transition-colors"&gt;Termos&lt;/Link&gt;
            &lt;Link href="#" className="hover:text-foreground transition-colors"&gt;Privacidade&lt;/Link&gt;
            &lt;Link href="#" className="hover:text-foreground transition-colors"&gt;Suporte&lt;/Link&gt;
          &lt;/div&gt;
        &lt;/div&gt;
      &lt;/footer&gt;
    &lt;/div&gt;
  )
}

function FeatureCard({ icon: Icon, title, description }: { icon: React.ElementType; title: string; description: string }) {
  return (
    &lt;div className="p-6 rounded-xl bg-card border border-border hover:border-primary/30 transition-colors group"&gt;
      &lt;div className="size-10 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors"&gt;
        &lt;Icon className="size-5 text-primary" /&gt;
      &lt;/div&gt;
      &lt;h3 className="font-semibold mb-2"&gt;{title}&lt;/h3&gt;
      &lt;p className="text-sm text-muted-foreground"&gt;{description}&lt;/p&gt;
    &lt;/div&gt;
  )
}

function BenefitItem({ icon: Icon, text }: { icon: React.ElementType; text: string }) {
  return (
    &lt;div className="flex items-center gap-3 p-4 rounded-lg bg-card border border-border"&gt;
      &lt;div className="size-8 rounded-md bg-primary/10 flex items-center justify-center shrink-0"&gt;
        &lt;Icon className="size-4 text-primary" /&gt;
      &lt;/div&gt;
      &lt;span className="text-sm"&gt;{text}&lt;/span&gt;
    &lt;/div&gt;
  )
}

function PricingFeature({ text }: { text: string }) {
  return (
    &lt;div className="flex items-center gap-2"&gt;
      &lt;CheckCircle2 className="size-4 text-primary shrink-0" /&gt;
      &lt;span className="text-sm"&gt;{text}&lt;/span&gt;
    &lt;/div&gt;
  )
}
